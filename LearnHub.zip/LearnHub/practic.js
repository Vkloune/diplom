   document.querySelectorAll('.typewriter').forEach(element => {
      const text = element.textContent;
      const dummy = document.createElement('span');
      dummy.style.visibility = 'hidden';
      dummy.style.whiteSpace = 'nowrap';
      dummy.textContent = text;
      
      document.body.appendChild(dummy);
      const width = dummy.offsetWidth;
      document.body.removeChild(dummy);

      element.style.setProperty('--text-width', `${width}px`);
      element.style.animation = `typing 3s steps(${text.length}, end) forwards`;
    });