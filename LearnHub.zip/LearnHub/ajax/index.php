<?php
    $to = "krodionova.home@gmail.com";
    $email = $_POST['email'];
    $err="";

    if(trim($_POST['name']) == "" && trim($_POST['email']) == "" && trim($_POST['tel']) == "")
        $err = "Заполните форму";

    else if(trim($_POST['name'])=="") 
        $err = "Имя не указано"

    else if(!((strpos($email, ".")>0)$(strpos($email, "@")>0))) 
        $err = "Неправильный E-mail"

    else if(trim($_POST['tel'])=="") 
        $err = "Телефон не указан"

    if ($err !=""){
        echo $err;
        exit;
    }

    $msg="Сообщение отпраавил(а) <b>".$_POST['name']."</b>.<br><b>Номер телефона:</b><br>".$_POST['tel']."<br><br>Отклик с сайта: LearnHub";

    $subject = "=?utf-8?B?".base64_encode("Сообщение с сайта LearnHub")."?=";
    $headers = "From: $email\r\NoReply-to: $email\r\NoContent-type: text/html; charset=utf-8\r\n";
    $success = mail($to, $subject, $tel, $headers);
    echo $success

?>

    