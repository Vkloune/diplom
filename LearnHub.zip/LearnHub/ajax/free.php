<?php
$to = "krodionova.home@gmail.com";
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$tel = trim($_POST['tel']);
$err = "";

// Валидация данных
if(empty($name) && empty($email) && empty($tel)) {
    $err = "Заполните форму";
} elseif(empty($name)) {
    $err = "Имя не указано";
} elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $err = "Неправильный E-mail";
} elseif(empty($tel)) {
    $err = "Телефон не указан";
}

if ($err != ""){
    echo $err;
    exit;
}

// Формирование сообщения
$subject = "Новая заявка с сайта LearnHub";
$message = "
<html>
<head>
    <title>Новая заявка</title>
</head>
<body>
    <p>Сообщение отправил(а) <b>".htmlspecialchars($name)."</b></p>
    <p><b>Email:</b> ".htmlspecialchars($email)."</p>
    <p><b>Телефон:</b> ".htmlspecialchars($tel)."</p>
    <p>Отклик с сайта: LearnHub</p>
</body>
</html>
";

// Заголовки
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "From: LearnHub <noreply@learnhub.example>\r\n"; // Замените на ваш домен
$headers .= "Reply-To: ".htmlspecialchars($email)."\r\n";

// Отправка
$success = mail($to, $subject, $message, $headers);

if ($success) {
    echo "Сообщение успешно отправлено!";
} else {
    echo "Ошибка при отправке сообщения. Пожалуйста, попробуйте позже.";
    
    // Для диагностики (удалите в боевом режиме)
    error_log("Ошибка отправки почты: " . print_r(error_get_last(), true));
}
?>