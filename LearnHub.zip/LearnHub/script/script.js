$(document).ready(function(){
    $('.bxslider').bxSlider({
        pager: false,
    });
});